#define SIGS_FROM_OSST \
       {"OnStream", "SC-", "", "osst"}, \
       {"OnStream", "DI-", "", "osst"}, \
       {"OnStream", "DP-", "", "osst"}, \
       {"OnStream", "FW-", "", "osst"}, \
       {"OnStream", "USB", "", "osst"}
